package lk.ijse.metleCrusher.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.metleCrusher.dto.EmployeeDto;
import lk.ijse.metleCrusher.dto.tm.EmployeeTm;
import lk.ijse.metleCrusher.model.EmployeeModel;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class EmployeeFormController {
    public AnchorPane root;

    @FXML
    private TextField txtEmpAddress;

    @FXML
    private TextField txtEmpGande;

    @FXML
    private TextField txtEmpId;

    @FXML
    private TextField txtEmpName;

    @FXML
    private TextField txtEmpNic;

    @FXML
    private TextField txtEmpSalary;

    @FXML
    private TextField txtEmpTel;

    @FXML
    private TableColumn<?, ?> colAddress;

    @FXML
    private TableColumn<?, ?> colGander;

    @FXML
    private TableColumn<?, ?> colId;

    @FXML
    private TableColumn<?, ?> colName;

    @FXML
    private TableColumn<?, ?> colNic;

    @FXML
    private TableColumn<?, ?> colSalary;

    @FXML
    private TableColumn<?, ?> colTel;

    @FXML
    private TableView<EmployeeTm> tblEmployee;

    private EmployeeModel empModel = new EmployeeModel();

    public void initialize() {
        setCellValueFactory();
        LoadAllEmployee();
    }
    private void setCellValueFactory() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNic.setCellValueFactory(new PropertyValueFactory<>("nic"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        colGander.setCellValueFactory(new PropertyValueFactory<>("gander"));
        colTel.setCellValueFactory(new PropertyValueFactory<>("tel"));
        colSalary.setCellValueFactory(new PropertyValueFactory<>("salary"));
    }
    private void LoadAllEmployee() {
        var model = new EmployeeModel();

        ObservableList<EmployeeTm> obList = FXCollections.observableArrayList();

        try {
            List<EmployeeDto> dtoList = model.getAllEmployee();

            for (EmployeeDto dto : dtoList) {
                obList.add(
                        new EmployeeTm(
                                dto.getId(),
                                dto.getNic(),
                                dto.getName(),
                                dto.getAddress(),
                                dto.getGander(),
                                dto.getTel(),
                                dto.getSalary()
                        )
                );
            }

            tblEmployee.setItems(obList);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void EmpSearchOnAction(ActionEvent event) {
        String id = txtEmpId.getText();

//        var model = new EmployeeModel();
        try {
            EmployeeDto employeeDto = empModel.searchEmployee(id);
//            System.out.println(employeeDto);
            if (employeeDto != null) {
                txtEmpId.setText(employeeDto.getId());
                txtEmpNic.setText(employeeDto.getName());
                txtEmpName.setText(employeeDto.getAddress());
                txtEmpAddress.setText(employeeDto.getTel());
                txtEmpGande.setText(employeeDto.getTel());
                txtEmpTel.setText(employeeDto.getTel());
                txtEmpSalary.setText(employeeDto.getTel());
            } else {
                new Alert(Alert.AlertType.INFORMATION, "Employee Not Found :(").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }

    }

    @FXML
    void btnClearOnActionEmplloyee(ActionEvent event) {
        clearFields();
    }
    private void clearFields() {
        txtEmpId.setText("");
        txtEmpNic.setText("");
        txtEmpName.setText("");
        txtEmpAddress.setText("");
        txtEmpGande.setText("");
        txtEmpTel.setText("");
        txtEmpSalary.setText("");
    }

    @FXML
    void btnDeleteOnAntionEmployee(ActionEvent event) {
        String id = txtEmpId.getText();

//        var model = new employeeModel();
        try {
            boolean isDeleted = empModel.deleteEmployee(id);
            if (isDeleted) {
                new Alert(Alert.AlertType.CONFIRMATION, "Employee Deleted!").show();
            } else {
                new Alert(Alert.AlertType.CONFIRMATION, "Employee Not Deleted!").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }


    }

    @FXML
    void btnEmployeeIdanCustomer(ActionEvent event) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/customer_form.fxml"));
        Stage stage = (Stage) root.getScene().getWindow();

        stage.setScene(new Scene(anchorPane));
        stage.setTitle("Customer Manage");
        stage.centerOnScreen();
    }

    @FXML
    void btnEmployeeIdanPlaceOrder(ActionEvent event) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/placeorder_form.fxml"));
        Stage stage = (Stage) root.getScene().getWindow();

        stage.setScene(new Scene(anchorPane));
        stage.setTitle("Place Order");
        stage.centerOnScreen();
    }

    @FXML
    void btnEmplyoyeeIdanItem(ActionEvent event) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/item_form.fxml"));
        Stage stage = (Stage) root.getScene().getWindow();

        stage.setScene(new Scene(anchorPane));
        stage.setTitle("Item Manage");
        stage.centerOnScreen();
    }

    @FXML
    void btnSaveOnActionEmployee(ActionEvent event) {
        String id = txtEmpId.getText();
        String nic = txtEmpNic.getText();
        String name = txtEmpName.getText();
        String address = txtEmpAddress.getText();
        String gander = txtEmpGande.getText();
        String tel = txtEmpTel.getText();
        double salary = Double.parseDouble(txtEmpSalary.getText());

        var dto = new EmployeeDto(id, nic, name, address, gander, tel, salary);

        try {
            boolean isSaved = empModel.saveEmployee(dto);

            if (isSaved) {
                new Alert(Alert.AlertType.CONFIRMATION, "Employee Saved!").show();
                clearFields();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    @FXML
    void btnUpdateOnAntionEmployee(ActionEvent event) {
        String id = txtEmpId.getText();
        String nic = txtEmpNic.getText();
        String name = txtEmpName.getText();
        String address = txtEmpAddress.getText();
        String gander = txtEmpGande.getText();
        String tel = txtEmpTel.getText();
        double salary = Double.parseDouble(txtEmpSalary.getText());

        var dto = new EmployeeDto(id, nic, name, address, gander, tel, salary);

//        var model = new EmployeeModel();
        try {
            boolean isUpdated = empModel.updateEmployee(dto);
            if (isUpdated) {
                new Alert(Alert.AlertType.CONFIRMATION, "Employee Updated ! :)").show();
                clearFields();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }
    @FXML
    void btnBackOnAction(ActionEvent event) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/dashboard_form.fxml"));
        Stage stage = (Stage) root.getScene().getWindow();

        stage.setScene(new Scene(anchorPane));
        stage.setTitle("Dashboard");
        stage.centerOnScreen();

    }

}
