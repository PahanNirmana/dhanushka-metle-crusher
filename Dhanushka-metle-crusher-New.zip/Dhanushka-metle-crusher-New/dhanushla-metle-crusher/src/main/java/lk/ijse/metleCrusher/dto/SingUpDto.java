package lk.ijse.metleCrusher.dto;

public class SingUpDto {
}
